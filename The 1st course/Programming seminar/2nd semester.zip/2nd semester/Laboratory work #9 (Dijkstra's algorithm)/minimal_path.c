#include "minimal_path.h"

int min_path(int **table, int number_of_vertices, int number_of_edges, int start,
        long long int **dist, int **min_path)
{
        *dist = (long long int*)malloc(sizeof(long long int) * number_of_vertices);
        *min_path = (int*)malloc(sizeof(int) * number_of_vertices);
        int *visited = (int*)malloc(sizeof(int) * number_of_vertices);
        if(!(*dist) || !(*min_path) || !visited){
                free(visited);
                return -1;
        }
        for(size_t i = 0; i < number_of_vertices; i++){
                (*dist)[i] = LLONG_MAX;
                visited[i] = 0;
                (*min_path)[i] = i;
        }
        (*dist)[start - 1] = 0;
        visited[start - 1] = 1;
        int current_vertex = start - 1, future_vertex = current_vertex;
        int current_num_of_vertices = number_of_vertices;
        while(--current_num_of_vertices > 0){
                long long int min_dist = LLONG_MAX;
                for(int i = 0; i < number_of_vertices; i++){
                        long long int distance;
                        if((*dist)[current_vertex] == LLONG_MAX ||
                         table[current_vertex][i] == -1)
                                distance = LLONG_MAX;
                        else
                                distance = (*dist)[current_vertex]
                                 + table[current_vertex][i];
                        /* update the information about current the shortest way */
                        if(!visited[i]){
                                if((*dist)[i] > distance){
                                        (*dist)[i] = (*dist)[current_vertex]
                                         + table[current_vertex][i];
                                         (*min_path)[i] = current_vertex;
                                 }
                                 if((*dist)[i] < min_dist){
                                         min_dist = (*dist)[i];
                                         future_vertex = i;
                                 }
                         }
                 }
                 visited[current_vertex = future_vertex] = 1;
        }
        free(visited);
        return 0;
}
