#include "graph/graph.h"
#include "minimal_path.h"

int main()
{
	int number_of_vertices = 0, number_of_edges = 0, start = 0, finish = 0;

	switch(test_graph(stdin, &number_of_vertices, &number_of_edges, &start,
                &finish)){
		case -1: printf("bad number of lines"); return 0;
		case -2: printf("bad number of vertices"); return 0;
		case -3: printf("bad number of edges"); return 0;
                case -4: printf("NULL pointer exception"); return 0;
                case -5: printf("bad vertex"); return 0;
	}

        int **table = create_vertex_table(number_of_vertices);
        if(!table){
                printf("no memory for allocation");
                return 0;
        }

        int ERROR_FLAG = 0;
	switch(get_graph_table(stdin, table, number_of_edges, number_of_vertices)){
		case -1: printf("bad vertex"); ERROR_FLAG = 1; break;
		case -2: printf("bad number of lines"); ERROR_FLAG = 1; break;
                case -3: printf("bad length"); ERROR_FLAG = 1; break;
                case -4: printf("NULL pointer exception"); ERROR_FLAG = 1; break;
	}

        long long int *min_dist = NULL;
        int *path = NULL;
        if(!ERROR_FLAG && !min_path(table, number_of_vertices, number_of_edges,
                start, &min_dist,&path))
        {
                int num_of_paths = 0;
                for(size_t i = 0; i < number_of_vertices; i++){
                        if(min_dist[i] == LLONG_MAX)
                                printf("oo ");
                        else
                        if(min_dist[i] > INT_MAX)
                                printf("INT_MAX+ ");
                        else
                                printf("%lld ",min_dist[i]);
                        if(table[finish - 1][i] != -1)
                                num_of_paths++;
                }
                printf("\n");
                if(min_dist[finish - 1] != LLONG_MAX){
                        if(min_dist[finish - 1] > INT_MAX && num_of_paths > 1){
                                printf("overflow");
                                ERROR_FLAG = 1;
                        }
                }
                else{
                        printf("no path");
                        ERROR_FLAG = 1;
                }
                if(!ERROR_FLAG){
                        size_t i = finish - 1;
                        while(path[i] != i){
                                printf("%lu ", i + 1);
                                i = path[i];
                        }
                        printf("%lu", i + 1);
                }
        }
        free_graph(table, number_of_vertices);
        free(min_dist);
        free(path);
	return 0;
}
