#include "graph.h"

int **create_vertex_table(int number_of_vertices)
{
	int **table = (int**)malloc(sizeof(int*) * number_of_vertices);

        if(table){
                size_t i = 0;
                for(; i < number_of_vertices; i++){
                        table[i] = (int*)malloc(sizeof(int) * number_of_vertices);
                        if(!table[i]) break;
                        memset(table[i], -1, sizeof(int) * number_of_vertices);
                }
                if(i != number_of_vertices){
                        for(size_t k = 0; k < i; k++)
                                free(table[i]);
                        free(table);
                        table = NULL;
                }
        }

	return table;
}

void connect_vertices(int **table, int from, int to, int length)
{
	table[from - 1][to - 1] = length;
        table[to - 1][from - 1] = length;
}

int test_graph(FILE* stream, int *number_of_vertices, int *number_of_edges,
        int *start, int *finish)
{
        if(!stream || !number_of_edges || !number_of_edges || !start || !finish)
                return -4;
	if(fscanf(stream, "%d%d%d%d", number_of_vertices, start, finish,
                number_of_edges) != 4)
		return -1;
        if(*number_of_vertices < 0 || *number_of_vertices > MAX_VERTEX)
		return -2;
        if(*start < 1 || *start > *number_of_vertices || *finish < 1
        || *finish > *number_of_vertices)
                return -5;
	if(*number_of_edges < 0 || *number_of_edges > (*number_of_vertices *
                (*number_of_vertices + 1) / 2))
		return -3;

	return 0;
}

int get_graph_table(FILE* stream, int **vertex_table, int number_of_edges,
         int number_of_vertices)
{
	if(!stream || !vertex_table)
                return -4;
        size_t i = 0;
	for(; i < number_of_edges; i++){
                int from = 0, to = 0;
                long long int length = 0;
		if(fscanf(stream, "%d%d%lld", &from, &to, &length) != 3)
			break;
		if(from < 1 || from > number_of_vertices || to < 1
                        || to > number_of_vertices)
			return -1;
                if(length < 0 || length > INT_MAX)
                        return -3;
		connect_vertices(vertex_table, from, to, length);
	}
	/* function read lesser data than need */
	if(i < number_of_edges)
		return -2;

	return 0;
}

void free_graph(int **vertex_table, int number_of_vertices)
{
        if(!vertex_table)
                return;
	for(size_t i = 0; i < number_of_vertices; i++)
		free(vertex_table[i]);
	free(vertex_table);
}
