#ifndef GRAPH_H
#define GRAPH_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <limits.h>

#ifndef MAX_VERTEX
#define MAX_VERTEX 5000
#endif

/* MAIN GRAPH FUNCTIONS */

/* create adjacency table */
int **create_vertex_table(int number_of_vertices);

/* check a graph for a bad input */
int test_graph(FILE* stream, int *number_of_vertices, int *number_of_edges,
        int *start, int *finish);

/* get adjacency table */
int get_graph_table(FILE* stream, int **vertex_table,
        int number_of_edges, int number_of_vertices);

/* free the memory alocated for a graph */
void free_graph(int **vertex_table, int number_of_vertices);

#endif /* GRAPH_H */
