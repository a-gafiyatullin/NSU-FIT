#ifndef MINIMAL_PATH
#define MINIMAL_PATH

#include <limits.h>
#include <stddef.h>
#include <stdlib.h>

/* find the shortest ways from "start" vertex up to the each vertex of a graph */
int min_path(int **table, int number_of_vertices, int number_of_edges,
         int start, long long int **dest, int **min_path);

#endif /* MINIMAL_PATH */
