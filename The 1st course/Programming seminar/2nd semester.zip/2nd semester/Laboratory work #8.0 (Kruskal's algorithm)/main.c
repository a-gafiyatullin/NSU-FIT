#include "graph.h"
#include "stdlib.h"
#include "stdio.h"

int compare_edges(const void *left, const void *right)
{
        return ((struct edge*)left)->length - ((struct edge*)right)->length;
}

int main()
{
	int number_of_vertices = 0, number_of_edges = 0;
        FILE *in = fopen("in.txt", "r");
        FILE *out = fopen("out.txt", "w");
        assert(in && out);

	switch(test_graph(in, &number_of_vertices, &number_of_edges)){
		case -1: printf("bad number of lines"); return 0;
		case -2: printf("bad number of vertices"); return 0;
		case -3: printf("bad number of edges"); return 0;
	}

        struct edge *edge_list = (struct edge*)malloc(sizeof(struct edge) * number_of_edges);
        assert(edge_list);

	switch(get_graph_table(in, edge_list, number_of_edges, number_of_vertices)){
		case -1: printf("bad vertex"); return 0;
		case -2: printf("bad number of lines"); return 0;
                case -3: printf("bad length"); return 0;
	}

        qsort(edge_list, number_of_edges, sizeof(struct edge), compare_edges);

        int processed_vertices = number_of_vertices;
        struct edge *mst = build_mst(edge_list, &processed_vertices, number_of_edges);

        if(number_of_vertices - processed_vertices != number_of_vertices - 1){
                fprintf(out, "no spanning tree\n");
                return 0;
        }

        for(size_t i = 0; i < number_of_vertices - 1; i++)
                fprintf(out, "%d %d\n", mst[i].from, mst[i].to);

        free(edge_list);
        free(mst);
        fclose(in);
        fclose(out);

	return 0;
}
