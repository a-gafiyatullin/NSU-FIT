#ifndef GRAPH_H
#define GRAPH_H

#ifndef MAX_VERTEX
#define MAX_VERTEX 5000
#endif

#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include "limits.h"
#include "stdio.h"
#include "DSU/dsu.h"

struct edge{
        signed short from;
        signed short to;
        int length;
};

/* check a graph for a bad input */
int test_graph(FILE* stream, int *number_of_vertices, int *number_of_edges);

/* get adjacency table */
int get_graph_table(FILE* stream, struct edge *edge_list,
        int number_of_edges, int number_of_vertices);

/* create a minimal spanning tree of a graph using sorted list of edges */
struct edge *build_mst(struct edge *edge_list,
        int *number_of_vertices, int number_of_edges);

#endif /* GRAPH_H */
