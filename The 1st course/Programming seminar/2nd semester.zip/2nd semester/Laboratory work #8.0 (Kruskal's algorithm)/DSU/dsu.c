#include "dsu.h"
#include "stdio.h"

void swap(int *left, int *right)
{
        int tmp = *left;
        *left = *right;
        *right = tmp;
}

int *init_dsu(int number_of_sets, int **sets_height)
{
        int *dsu_array = (int*)malloc(sizeof(int) * number_of_sets);
        *sets_height = (int*)malloc(sizeof(int) * number_of_sets);
        assert(dsu_array && *sets_height);

        for(int i = 0; i < number_of_sets; i++){
                dsu_array[i] = i;
                (*sets_height)[i] = 0;
        }

        return dsu_array;
}

int find_leader(int *dsu_array, int element)
{
        if(element == dsu_array[element])
                return element;
        return dsu_array[element] = find_leader(dsu_array, dsu_array[element]);
}

int union_sets(int *dsu_array, int *sets_height, int first_element,
         int second_element)
{
        assert(dsu_array && sets_height);

        first_element = find_leader(dsu_array, first_element);
        second_element = find_leader(dsu_array, second_element);

        if(first_element != second_element){
                if(sets_height[first_element] < sets_height[second_element])
                        swap(&first_element, &second_element);
                dsu_array[second_element] = first_element;
                if(sets_height[first_element] == sets_height[second_element])
                        sets_height[first_element]++;
        }

        return first_element;
}

void free_dsu(int *dsu, int *sets_height)
{
        free(dsu);
        free(sets_height);
}
