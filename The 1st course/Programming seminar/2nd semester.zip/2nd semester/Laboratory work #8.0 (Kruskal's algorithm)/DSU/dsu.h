#ifndef DSU
#define DSU

#include "stdlib.h"
#include "assert.h"

/* create sets consisted of one element */
int *init_dsu(int number_of_sets, int **sets_height);

/* find the leader element of set said element */
int find_leader(int *dsu_array, int element);

/*
 unite two sets which include said elements
 and return the leader element of the new set
*/
int union_sets(int *dsu_array, int *sets_height, int first_element,
         int second_element);

/* free the memory allocated for the dsu */
void free_dsu(int *dsu, int *sets_height);

#endif /* DSU */
