#include "graph.h"

int test_graph(FILE* stream, int *number_of_vertices, int *number_of_edges)
{
	assert(stream);

	if(fscanf(stream, "%d%d", number_of_vertices, number_of_edges) != 2)
		return -1;
	if(*number_of_vertices < 0 || *number_of_vertices > MAX_VERTEX)
		return -2;
	if(*number_of_edges < 0 || *number_of_edges > (*number_of_vertices *
                (*number_of_vertices + 1) / 2))
		return -3;

	return 0;
}

int get_graph_table(FILE* stream, struct edge *edge_list, int number_of_edges,
        int number_of_vertices)
{
	assert(stream && edge_list);

	int i = 0;
        int from = 0, to = 0;
        long long length = 0;
	for(i = 0; i < number_of_edges; i++){
		if(fscanf(stream, "%d%d%lld", &from, &to, &length) != 3)
                        break;
		if(from < 0 || from > number_of_vertices || to < 0 ||
                        to > number_of_vertices)
			return -1;
                if(length < 0 || length > INT_MAX)
                        return -3;
                edge_list[i].from = from;
                edge_list[i].to = to;
                edge_list[i].length = length;
	}
	/* function read lesser data than need */
	if(i < number_of_edges)
		return -2;

	return 0;
}

struct edge *build_mst(struct edge *edge_list, int *number_of_vertices,
         int number_of_edges)
{
        assert(edge_list);

        int *rank_table = NULL;
        int *dsu = init_dsu(*number_of_vertices, &rank_table);

        int i = 0;
        struct edge *mst = (struct edge*)malloc(sizeof(struct edge) * number_of_edges);
        assert(mst);

        while(*number_of_vertices - 1 > 0 && number_of_edges > 0){
                if(find_leader(dsu, edge_list->from - 1) !=
                        find_leader(dsu, edge_list->to - 1)){
                        mst[i++] = *edge_list;
                        union_sets(dsu, rank_table, edge_list->from - 1,
                                edge_list->to - 1);
                        edge_list++;
                        (*number_of_vertices)--;
                }
                else
                        edge_list++;

                number_of_edges--;
        }

        free_dsu(dsu, rank_table);
        return mst;
}
