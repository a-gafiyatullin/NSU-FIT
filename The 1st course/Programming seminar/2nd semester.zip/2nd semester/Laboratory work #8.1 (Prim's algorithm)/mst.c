#include "mst.h"

struct edge *minimal_edge(int **vertex_table, int *minimal_distance,
         int *vertex_visited, int number_of_vertices, int visited)
{
        struct edge *new_edge = (struct edge*)malloc(sizeof(struct edge));
        assert(vertex_table && minimal_distance && vertex_visited && new_edge);

        long long int current_min_dest = INT_MAX;
        int to = -1, from = 0;

        for(int i = 0; i < number_of_vertices; i++){
                int min_dest_from = minimal_distance[i];
                if(!vertex_visited[i]){
                        /* update minimal distance up to the each vertex */
                        if(vertex_table[visited][i] != -1 &&
                        (vertex_table[visited][i] < vertex_table[min_dest_from][i]
                        || vertex_table[min_dest_from][i] == -1))
                                minimal_distance[i] = visited;
                        min_dest_from = minimal_distance[i];
                        /* find current minimal edge */
                        if(vertex_table[min_dest_from][i] != - 1 &&
                        vertex_table[min_dest_from][i] <= current_min_dest){
                                current_min_dest = vertex_table[min_dest_from][i];
                                from = min_dest_from;
                                to = i;
                        }
                }
        }
        new_edge->from = from;
        new_edge->to = to;
        new_edge->length = current_min_dest;

        return new_edge;
}

struct edge **build_mst(int **vertex_table, int *number_of_vertices)
{
        int processed_vertices = *number_of_vertices - 1;
        int *vertex_visited = (int*)malloc(sizeof(int) * *number_of_vertices);
        int *minimal_distance = (int*)malloc(sizeof(int) * *number_of_vertices);
        struct edge **mst = (struct edge**)malloc(sizeof(struct edge*) * *number_of_vertices);
        assert(vertex_visited && minimal_distance && mst);
        memset(vertex_visited, 0, sizeof(int) * *number_of_vertices);
        memset(minimal_distance, 0, sizeof(int) * *number_of_vertices);
        vertex_visited[0] = 1;
        int i = 0, to = 0, visited = 0;
        while(processed_vertices > 0){
                mst[i] = minimal_edge(vertex_table, minimal_distance,
                        vertex_visited, *number_of_vertices, visited);
                if((to = mst[i++]->to) == -1){
                        free_mst(mst, i);
                        mst = NULL;
                        break;
                }
                vertex_visited[to] = 1;
                visited = to;
                processed_vertices--;
        }
        *number_of_vertices = processed_vertices;

        free(vertex_visited);
        free(minimal_distance);
        return mst;
}

void free_mst(struct edge **mst, int number_of_edges)
{
        if(mst)
        for(int i = 0; i < number_of_edges; i++)
                free(mst[i]);
        free(mst);
}
