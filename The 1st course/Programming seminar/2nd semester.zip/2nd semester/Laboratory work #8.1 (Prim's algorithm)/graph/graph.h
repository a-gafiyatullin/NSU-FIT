#ifndef GRAPH_H
#define GRAPH_H

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#ifndef MAX_VERTEX
#define MAX_VERTEX 5000
#endif

/* MAIN GRAPH FUNCTIONS */

/* create adjacency table */
int **create_vertex_table(int);

/* connect two vertices in the graph */
void connect_vertices(int**, int, int, int);

/* check a graph for a bad input */
int test_graph(FILE*, int*, int*);

/* get adjacency table */
int get_graph_table(FILE*, int**, int, int);

/* free the memory alocated for a graph */
void free_graph(int**, int);

#endif /* GRAPH_H */
