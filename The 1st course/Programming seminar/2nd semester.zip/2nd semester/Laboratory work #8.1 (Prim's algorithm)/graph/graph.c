#include "graph.h"

int **create_vertex_table(int number_of_vertices)
{
	int **table = (int**)malloc(sizeof(int*) * number_of_vertices);
	assert(table);

	for(int i = 0; i < number_of_vertices; i++){
		table[i] = (int*)malloc(sizeof(int) * number_of_vertices);
		assert(table[i]);
		memset(table[i], -1, sizeof(int) * number_of_vertices);
	}

	return table;
}

void connect_vertices(int **table, int from, int to, int length)
{
        assert(table);
	table[from - 1][to - 1] = length;
        table[to - 1][from - 1] = length;
}

int test_graph(FILE* stream, int *number_of_vertices, int *number_of_edges)
{
	assert(stream);

	if(fscanf(stream, "%d%d", number_of_vertices, number_of_edges) != 2)
		return -1;
	if(*number_of_vertices < 0 || *number_of_vertices > MAX_VERTEX)
		return -2;
	if(*number_of_edges < 0 || *number_of_edges > (*number_of_vertices *
                (*number_of_vertices + 1) / 2))
		return -3;

	return 0;
}

int get_graph_table(FILE* stream, int **vertex_table, int number_of_edges,
         int number_of_vertices)
{
	assert(stream && vertex_table);

        int from = 0, to = 0, i = 0;
        long long int length = 0;
	for(i = 0; i < number_of_edges; i++){
		if(fscanf(stream, "%d%d%lld", &from, &to, &length) != 3)
			break;
		if(from < 0 || from > number_of_vertices || to < 0
                        || to > number_of_vertices)
			return -1;
                if(length < 0 || length > INT_MAX)
                        return -3;
		connect_vertices(vertex_table, from, to, length);
	}
	/* function read lesser data than need */
	if(i < number_of_edges)
		return -2;

	return 0;
}

void free_graph(int **vertex_table, int number_of_vertices)
{
	for(int i = 0; i < number_of_vertices; i++)
		free(vertex_table[i]);
	free(vertex_table);
}
