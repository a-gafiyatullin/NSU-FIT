#include "mst.h"

int main()
{
	int number_of_vertices = 0, number_of_edges = 0;
        FILE *in = stdin;
        FILE *out = stdout;

	switch(test_graph(in, &number_of_vertices, &number_of_edges)){
		case -1: printf("bad number of lines"); return 0;
		case -2: printf("bad number of vertices"); return 0;
		case -3: printf("bad number of edges"); return 0;
	}

        int **vertex_table = create_vertex_table(number_of_vertices);
	switch(get_graph_table(in, vertex_table, number_of_edges, number_of_vertices)){
		case -1: printf("bad vertex"); return 0;
		case -2: printf("bad number of lines"); return 0;
                case -3: printf("bad length"); return 0;
	}

        int processed_vertices = number_of_vertices ;
        struct edge **mst = build_mst(vertex_table, &processed_vertices);

        if(processed_vertices != 0)
                printf("no spanning tree");
        else
        for(size_t i = 0; i < number_of_vertices - 1; i++)
                fprintf(out,"%d %d\n", mst[i]->from + 1, mst[i]->to + 1);

        free_graph(vertex_table, number_of_vertices);
        free_mst(mst, number_of_vertices - 1);
	return 0;
}
