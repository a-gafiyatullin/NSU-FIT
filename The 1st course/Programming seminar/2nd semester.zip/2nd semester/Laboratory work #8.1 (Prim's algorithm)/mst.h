#ifndef MST
#define MST

#include "graph/graph.h"

struct edge{
        int from;
        int to;
        int length;
};

/* build a minimal spanning tree of the graph with the said table of verteces */
struct edge **build_mst(int **vertex_table, int *number_of_vertices);

/* free the memory allocated for a minimal spanning  tree */
void free_mst(struct edge **mst, int number_of_edges);

#endif /* MST */
