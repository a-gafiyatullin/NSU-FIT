#ifndef PRIORITY_Q
#define PRIORITY_Q

#include <stdlib.h>

/* a structure element of our priority queue for any types */
struct node_q
{
	void *data;
	struct node_q *next;
};

/* push an element to the queue */
int push_q(struct node_q **head, void *data,
	int (*cmp)(const void *left, const void *right));

/* pop the top element from the queue and return it */
void *pop_q(struct node_q **head);

#endif /* PRIORITY_Q */
