#include "priority_q.h"

int push_q(struct node_q **head, void *data,
        int (*cmp)(const void *left, const void *right))
{
        if(!data || !cmp)
                return -1;

	struct node_q *new_node = (struct node_q*)malloc(sizeof(struct node_q));
	if(!new_node)
		return -2;
	new_node->data = data;
        struct node_q *current = *head, *parent = *head;
        while(current){
                if(cmp(data, current->data) <= 0)
                        break;
                parent = current;
                current = current->next;
        }
        if(current == *head){
                *head = new_node;
        }
        else
                parent->next = new_node;
        new_node->next = current;

        return 0;
}

void *pop_q(struct node_q **head)
{
	if(!*head)
		return NULL;

	void *data = (*head)->data;
	struct node_q *next_node = (*head)->next;
	free(*head);
	*head = next_node;

	return data;
}
