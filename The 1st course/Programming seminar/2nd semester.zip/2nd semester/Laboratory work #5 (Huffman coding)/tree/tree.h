#ifndef TREE_H
#define TREE_H

#include <stdlib.h>
#include <limits.h>

/* structural element of our tree for any types */
struct tree_node
{
	unsigned char symbol;
	unsigned long long int data;
	struct tree_node *right_child;
	struct tree_node *left_child;
};

/* create a new tree node with the said data */
struct tree_node *create_node(unsigned char symbol, unsigned long long data);

/* merge two subtrees */
struct tree_node *merge_subtrees(struct tree_node *left_child,
	struct tree_node *right_child);

/* free the memory allocated for the tree */
void free_tree(struct tree_node *root);

#endif /* TREE_H */
