#include "tree.h"

struct tree_node *create_node(unsigned char symbol, unsigned long long data)
{
        struct tree_node *element =
                (struct tree_node*)malloc(sizeof(struct tree_node));
        if(!element)
                return NULL;
        element->data = data;
        element->symbol = symbol;
        element->left_child = element->right_child = NULL;

        return element;
}

struct tree_node *merge_subtrees(struct tree_node *left_child,
	struct tree_node *right_child)
{
        struct tree_node *new_node =
                (struct tree_node*)malloc(sizeof(struct tree_node));
        if(!new_node)
                return NULL;
        new_node->left_child = left_child;
        new_node->right_child = right_child;
        if(left_child->data < ULLONG_MAX / 2 && right_child->data < ULLONG_MAX / 2)
                new_node->data = left_child->data + right_child->data;
        else
                new_node->data = ULLONG_MAX - 1;

        return new_node;
}

void free_tree(struct tree_node *root)
{
        if(!root)
                return;
        free_tree(root->left_child);
        free_tree(root->right_child);
        free(root);
}
