#include <stdio.h>
#include "huffman_coding/huffman.h"
#include <string.h>

int main(int argc, char **argv)
{
        int COMMAND = 0, ERROR_FLAG = FALSE;
        FILE *in = NULL, *out = NULL;
        if(argc == 1){
                in = fopen("in.txt", "rb");
                out = fopen("out.txt", "wb");
                int command = fgetc(in);
                fgetc(in);
                fgetc(in);
                if(command == 'c')
                        compress(in, out, 1);
                else
                        decompress(in, out);
        }
        else{
                int i = 1;
                while(i < argc){
                        if(!(strcmp(argv[i], "-i"))){
                                if(i + 1 < argc){
                                        in = fopen(argv[i + 1], "rb");
                                        i += 2;
                                        if(!in){
                                                printf("cannot open file!\n");
                                                ERROR_FLAG = TRUE;
                                                break;
                                        }
                                }
                        }
                        else
                        if(!(strcmp(argv[i], "-o"))){
                                if(i + 1 < argc){
                                        out = fopen(argv[i + 1], "wb");
                                        i += 2;
                                        if(!out){
                                                printf("cannot create or open file!\n");
                                                ERROR_FLAG = TRUE;
                                                break;
                                        }
                                }
                        }
                        else
                        if(!(strcmp(argv[i], "-c"))){
                                COMMAND = 'c';
                                i++;
                        }
                        else
                        if(!(strcmp(argv[i], "-d"))){
                                COMMAND = 'd';
                                i++;
                        }
                        else{
                                printf("bad command!\n");
                                ERROR_FLAG = TRUE;
                                break;
                        }
                }
                if(!in || !out)
                        ERROR_FLAG = TRUE;
                if(!ERROR_FLAG)
                        switch(COMMAND){
                                case 'c': ERROR_FLAG = compress(in, out, 0); break;
                                case 'd': ERROR_FLAG = decompress(in, out); break;
                                default: printf("no such command!\n");
                        }
        }
        fclose(in);
        fclose(out);
        return ERROR_FLAG;
}
