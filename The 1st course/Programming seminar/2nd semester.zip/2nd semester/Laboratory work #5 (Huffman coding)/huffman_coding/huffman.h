#ifndef HUFFMAN
#define HUFFMAN

#include <stdio.h>
#include "../priority_q/priority_q.h"
#include "../tree/tree.h"

#define TRUE 1
#define FALSE 0

#define CHARSET_SIZE 256
#define BUFFER_SIZE 4096
#define CHAR_SIZE sizeof(unsigned char) * 8
typedef unsigned long long int ullong;
typedef unsigned char uchar;

/* compress data from input stream to output stream */
int compress(FILE *input, FILE *output, uchar command_in);

/* decompress data from input stream to output stream */
int decompress(FILE *input, FILE *output);

#endif /* HUFFMAN */
