#include "huffman.h"

/* create table of frequencies of the each symbol in the input stream */
ullong *stream_analysis(FILE *input, uchar command_in)
{
        char READ_FLAG = TRUE, ERROR_FLAG = FALSE;
        ullong *freq_table = (ullong*)calloc(CHARSET_SIZE, sizeof(ullong));
        uchar *buffer = (uchar*)malloc(BUFFER_SIZE * sizeof(uchar));
        if(!freq_table || !buffer)
                ERROR_FLAG = TRUE;
        if(!ERROR_FLAG){
                short i = 0, read;
                while(1){
                        if(READ_FLAG){
                                read =
                                fread(buffer, sizeof(uchar), BUFFER_SIZE, input);
                                if(!read) break;
                                READ_FLAG = FALSE;
                        }
                        if(freq_table[buffer[i]] != ULLONG_MAX - 1)
                                freq_table[buffer[i]]++;
                        i++;
                        if(i == read){
                                READ_FLAG = TRUE;
                                i = 0;
                        }
                }
        }
        free(buffer);
        if(ERROR_FLAG){
                free(freq_table);
                freq_table = NULL;
        }
        if(command_in)
                fseek(input, 3, SEEK_SET);
        else
                fseek(input, 0, SEEK_SET);
        return freq_table;
}

int cmp(const void *left, const void *right)
{
        return ((struct tree_node*)left)->data - ((struct tree_node*)right)->data;
}

/* create huffman prefix tree based on the table of the frequencies */
struct tree_node *create_huffman_tree(ullong *freq_table)
{
        struct node_q *q_head = NULL;
        uchar ERROR_FLAG = FALSE;
        for(int i = 0; i < CHARSET_SIZE; i++){
                if(freq_table[i]){
                        struct tree_node *new = create_node(i, freq_table[i]);
                        if(!new){
                                ERROR_FLAG = TRUE;
                                break;
                        }
                        if(push_q(&q_head, new, cmp)){
                                ERROR_FLAG = TRUE;
                                break;
                        }
                }
        }
        if(!ERROR_FLAG && q_head)
        while(q_head->next){
                struct tree_node *tmp = pop_q(&q_head);
                struct tree_node *new = merge_subtrees(tmp, pop_q(&q_head));
                if(!new){
                        ERROR_FLAG = TRUE;
                        break;
                }
                if(push_q(&q_head, new, cmp)){
                        ERROR_FLAG = TRUE;
                        break;
                }
        }
        if(ERROR_FLAG){
                while(q_head){
                        struct tree_node *temp = pop_q(&q_head);
                        free_tree(temp);
                }
                return NULL;
        }
        return pop_q(&q_head);
}

/* create tables of codes and its lengths for each symbol based on the prefix tree */
void create_code_table(struct tree_node *root, ullong *code_table,
        uchar *length_table, ullong code, uchar current_length)
{
        if(!(root->left_child) && !(root->right_child)){
                code_table[root->symbol] = code;
                length_table[root->symbol] = current_length;
                return;
        }
        create_code_table(root->left_child, code_table, length_table, code << 1,
                 current_length + 1);
        create_code_table(root->right_child, code_table, length_table,
                 (code << 1) + 1, current_length + 1);
}

/* save structure of the huffman tree in the output stream using DFS */
void save_huffman_tree(FILE *output, struct tree_node *root, uchar *byte,
        uchar *curr_num_of_bits)
{
        if(*curr_num_of_bits == CHAR_SIZE){
                fputc(*byte, output);
                *curr_num_of_bits = *byte = 0;
        }
        if(!(root->left_child) && !(root->right_child)){
                (*curr_num_of_bits)++;
                *byte |= 1 << (*curr_num_of_bits - 1);
                *byte |= root->symbol << *curr_num_of_bits;
                fputc(*byte, output);
                *byte = root->symbol >> (CHAR_SIZE - *curr_num_of_bits);
                return;
        }
        (*curr_num_of_bits)++;
        save_huffman_tree(output, root->left_child, byte, curr_num_of_bits);
        save_huffman_tree(output, root->right_child, byte, curr_num_of_bits);
}

/* analyse, compress and save alphabet of the input stream to the output stream */
int compress_alphabet(FILE *input, FILE *output, ullong **code_table,
         uchar **length_table, uchar command_in)
{
        ullong *freq_table = stream_analysis(input, command_in);
        if(!freq_table)
                return -1;
        struct tree_node *root = create_huffman_tree(freq_table);
        free(freq_table);
        if(!root)
                return -1;
        *code_table = (ullong*)malloc(CHARSET_SIZE * sizeof(ullong));
        *length_table = (uchar*)malloc(CHARSET_SIZE * sizeof(uchar));
        if(!(*code_table) || !(*length_table)){
                free(*code_table);
                free(*length_table);
                free_tree(root);
                return -1;
        }
        create_code_table(root, *code_table, *length_table, 0, 0);
        uchar num_of_bits = 0, byte = 0;
        save_huffman_tree(output, root, &byte, &num_of_bits);
        free_tree(root);
        if(num_of_bits != 0)
                fputc(byte, output);

        return 0;
}

int compress(FILE *input, FILE *output, uchar command_in)
{
        if(!input || !output)
                return -2;
        fputc(0, output);
        uchar *length_table, ERROR_FLAG = FALSE;
        ullong *code_table;
        if(compress_alphabet(input, output, &code_table, &length_table, command_in))
                return -1;
        uchar *in_buffer = (uchar*)calloc(BUFFER_SIZE, sizeof(uchar));
        uchar *out_buffer = (uchar*)calloc(BUFFER_SIZE, sizeof(uchar));
        if(!in_buffer || !out_buffer)
                ERROR_FLAG = TRUE;
        uchar READ_FLAG = TRUE;
        short read = 0, in_iter = 0, out_iter = 0, remainder = CHAR_SIZE;
        while(!ERROR_FLAG){
                if(READ_FLAG){
                        read = fread(in_buffer, sizeof(uchar), BUFFER_SIZE, input);
                        if(!read) break;
                        READ_FLAG = FALSE;
                }
                short code_len = length_table[in_buffer[in_iter]];
                ullong code = code_table[in_buffer[in_iter]];
                if(code_len == 0) code_len = 1;
                while(code_len > 0){
                        if(out_iter == BUFFER_SIZE){
                                fwrite(out_buffer, sizeof(uchar), BUFFER_SIZE, output);
                                out_iter = 0;
                                out_buffer[out_iter] = 0;
                        }
                        short shift = code_len - remainder;
                        if(shift >= 0){
                                out_buffer[out_iter] |= code >> shift;
                                code_len = shift;
                                remainder = CHAR_SIZE;
                        }
                        else{
                                out_buffer[out_iter] |= code << (-shift);
                                remainder = -shift;
                                break;
                        }
                        out_iter++;
                        out_buffer[out_iter] = 0;
                }
                in_iter++;
                if(in_iter == read){
                        READ_FLAG = TRUE;
                        in_iter = 0;
                }
        }
        free(in_buffer);
        if(!ERROR_FLAG){
                fwrite(out_buffer, sizeof(uchar), out_iter + 1, output);
                fseek(output, 0, SEEK_SET);
                fputc(remainder, output);
        }
        free(out_buffer);
        free(code_table);
        free(length_table);
        if(!ERROR_FLAG)
                return 0;
        else
                return -1;
}

/* repair the huffman tree structure from the input stream */
void decompress_tree(FILE *input, struct tree_node *root, uchar *byte,
        uchar *curr_num_of_bits)
{
        if(*curr_num_of_bits == CHAR_SIZE){
                *byte = fgetc(input);
                *curr_num_of_bits = 0;
        }
        if((*byte >> *curr_num_of_bits) & 1){
                (*curr_num_of_bits)++;
                uchar new_byte = fgetc(input);
                uchar symbol = (*byte >> *curr_num_of_bits)
                        + (new_byte << (sizeof(uchar) * 8 - *curr_num_of_bits));
                root->symbol = symbol;
                root->left_child = root->right_child = NULL;
                *byte = new_byte;
                return;
        }
        (*curr_num_of_bits)++;
        root->left_child = create_node(0, 0);
        decompress_tree(input, root->left_child, byte, curr_num_of_bits);
        root->right_child = create_node(0, 0);
        decompress_tree(input, root->right_child, byte, curr_num_of_bits);
}

int decompress(FILE *input, FILE *output)
{
        if(!input || !output)
                return -2;
        uchar remainder = getc(input), num_of_bits = 0, byte = getc(input),
                ERROR_FLAG = FALSE;
        if(feof(input)) return 0;
        struct tree_node *root = create_node(0, 0);
        decompress_tree(input, root, &byte, &num_of_bits);
        uchar *in_buffer = (uchar*)malloc(BUFFER_SIZE * sizeof(uchar));
        uchar *out_buffer = (uchar*)malloc(BUFFER_SIZE * sizeof(uchar));
        if(!in_buffer || !out_buffer)
                ERROR_FLAG = TRUE;
        uchar READ_FLAG = TRUE, mask = 1 << (CHAR_SIZE - 1);
        short in_iter = 0, out_iter = 0, read = 0;
        struct tree_node *current = root;
        while(!ERROR_FLAG){
                uchar current_remainder = 0;
                if(READ_FLAG){
                        read = fread(in_buffer, sizeof(uchar), BUFFER_SIZE, input);
                        if(!read) break;
                        READ_FLAG = FALSE;
                }
                if(in_iter == read - 1){
                        uchar tmp = getc(input);
                        if(feof(input))
                                current_remainder = remainder;
                        else
                                ungetc(tmp, input);
                }
                if(in_iter == read){
                        READ_FLAG = TRUE;
                        in_iter = 0;
                        continue;
                }
                while(current_remainder++ != CHAR_SIZE){
                        if((in_buffer[in_iter] & mask) && current->right_child != NULL)
                                current = current->right_child;
                        else
                        if(current->left_child != NULL)
                                current = current->left_child;
                        mask >>= 1;
                        if(!current->right_child && !current->left_child){
                                out_buffer[out_iter++] = current->symbol;
                                current = root;
                                if(out_iter == BUFFER_SIZE){
                                        fwrite(out_buffer, sizeof(uchar), BUFFER_SIZE, output);
                                        out_iter = 0;
                                }
                        }
                }
                mask = 1 << (CHAR_SIZE - 1);
                in_iter++;
        }
        free(in_buffer);
        if(!ERROR_FLAG)
                fwrite(out_buffer, sizeof(uchar), out_iter, output);
        free(out_buffer);
        free_tree(root);
        if(!ERROR_FLAG)
                return 0;
        else
                return -1;
}
