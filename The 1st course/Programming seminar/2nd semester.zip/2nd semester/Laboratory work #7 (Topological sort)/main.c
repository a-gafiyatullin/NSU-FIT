#include "graph.h"

int main()
{
        FILE *in = stdin;
	short number_of_vertices = 0;
        int number_of_edges = 0;

	switch(test_graph(in, &number_of_vertices, &number_of_edges)){
		case -1: printf("bad number of lines"); return 0;
		case -2: printf("bad number of vertices"); return 0;
		case -3: printf("bad number of edges"); return 0;
                case -4: printf("NULL pointer!"); return 0;
	}

	struct vertex **vertex_list = create_vertex_list(number_of_vertices);
        if(!vertex_list){
                printf("no memory for allocation!");
                return 0;
        }
        char ERROR_FLAG = 0;
	switch(get_graph_list(in, vertex_list, number_of_edges,
                 number_of_vertices)){
		case -1: printf("bad vertex"); ERROR_FLAG = 1; break;
		case -2: printf("bad number of lines"); ERROR_FLAG = 1; break;
                case -3: printf("NULL pointer!"); ERROR_FLAG = 1; break;
                case -4: printf("no memory for allocation!"); ERROR_FLAG = 1; break;
	}
        if(!ERROR_FLAG){
                short *sorted_graph = top_sort(vertex_list, number_of_vertices);
                if(sorted_graph)
                        for(short i = number_of_vertices - 1; i >= 0; i--)
                                printf("%d ", sorted_graph[i] + 1);
	                else
                                printf("impossible to sort");

                free(sorted_graph);
        }

	free_graph(vertex_list, number_of_vertices);

	return 0;
}
