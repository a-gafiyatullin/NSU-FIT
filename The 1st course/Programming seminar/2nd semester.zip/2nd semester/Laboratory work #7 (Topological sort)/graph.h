#ifndef GRAPH_H
#define GRAPH_H

#include <stdio.h>
#include <stdlib.h>
#include "stack/stack.h"

/* struct with the ending of the edge for a adjacency list */
struct vertex{
        short number;
        struct vertex *next;
};

/* MAIN GRAPH FUNCTIONS */

/* create adjacency list */
struct vertex **create_vertex_list(short number_of_vertices);

/* connect two vertices in the graph */
int connect_vertices(struct vertex **vertex_list, short from, short to);

/* check a graph for a bad input */
int test_graph(FILE* stream, short *number_of_vertices, int *number_of_edges);

/* get adjacency list */
int get_graph_list(FILE* stream, struct vertex **vertex_list, int number_of_edges,
         short number_of_vertices);

/* free the memory alocated for graph */
void free_graph(struct vertex **vertex_list, short number_of_vertices);

/* GRAPH FUNCTIONS FOR TOPOLOGICAL SORT */

/* topological sort of the said grap */
short *top_sort(struct vertex **vertex_list, short number_of_vertices);

#endif /* GRAPH_H */
