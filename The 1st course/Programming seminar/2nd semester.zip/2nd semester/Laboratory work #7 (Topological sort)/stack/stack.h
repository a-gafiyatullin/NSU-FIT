#ifndef STACK
#define STACK

#include <stdlib.h>

struct node{
        void *data;
        struct node *next;
};

/* push the data to the top of the stack */
int push_stack(struct node **head, void *data);

/* get and remove data from the top of the stack */
void *pop_stack(struct node **head);

/* free the stack */
void free_stack(struct node **head);

#endif /* STACK */
