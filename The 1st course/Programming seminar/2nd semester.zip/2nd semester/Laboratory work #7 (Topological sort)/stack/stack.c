#include "stack.h"

int push_stack(struct node **head, void *data)
{
        struct node *new_node = (struct node*)malloc(sizeof(struct node));
        if(!new_node)
                return -1;
        new_node->data = data;
        new_node->next = *head;
        *head = new_node;

        return 0;
}

void *pop_stack(struct node **head)
{
        if(!(*head))
                return NULL;
        struct node *element = *head;
        *head = (*head)->next;
        void *data = element->data;
        free(element);

        return data;
}

void free_stack(struct node **head)
{
        while(*head){
                struct node *current = *head;
                free(current->data);
                (*head) = (*head)->next;
                free(current);
        }
}
