#include "graph.h"

struct vertex **create_vertex_list(short number_of_vertices)
{
	return (struct vertex**)calloc(number_of_vertices, sizeof(struct vertex*));
}

int connect_vertices(struct vertex **list, short from, short to)
{
        struct vertex *new_vertex = (struct vertex*)malloc(sizeof(struct vertex));
        if(!new_vertex)
                return -1;

        new_vertex->number = to - 1;
        new_vertex->next = list[from - 1];
        list[from - 1] = new_vertex;

        return 0;
}

int test_graph(FILE* stream, short *number_of_vertices, int *number_of_edges)
{
	if(!stream || !number_of_edges || !number_of_edges)
                return -4;
	if(fscanf(stream, "%hu%d", number_of_vertices, number_of_edges) != 2)
		return -1;
	if(*number_of_vertices < 0 || *number_of_vertices > 1000)
		return -2;
	if(*number_of_edges < 0 || *number_of_edges > (*number_of_vertices *
                 (*number_of_vertices + 1) / 2))
		return -3;

	return 0;
}

int get_graph_list(FILE* stream, struct vertex **vertex_list, int number_of_edges,
         short number_of_vertices)
{
	if(!stream || !vertex_list)
                return -3;

	int i;
	for(i = 0; i < number_of_edges; i++){
		short from = 0, to = 0;
		if(fscanf(stream, "%hu%hu", &from, &to) != 2)
			break;
		if(from < 0 || from > number_of_vertices || to < 0 ||
                        to > number_of_vertices)
			return -1;
		if(connect_vertices(vertex_list, from, to))
                        return -4;
	}
	/* function read lesser data than need */
	if(i < number_of_edges)
		return -2;

	return 0;
}

void free_graph(struct vertex **vertex_list, short number_of_vertices)
{
	for(short i = 0; i < number_of_vertices; i++)
		while(vertex_list[i]){
                        struct vertex *next = vertex_list[i]->next;
                        free(vertex_list[i]);
                        vertex_list[i] = next;
                }
	free(vertex_list);
}

short *top_sort(struct vertex **vertex_list, short number_of_vertices)
{
        enum color{ WHITE, GREY, BLACK };
        char *vert_color = (char*)calloc(number_of_vertices, sizeof(char));
        short *vert_sorted = (short*)malloc(number_of_vertices * sizeof(short));
        if(!vert_color || !vert_sorted){
                free(vert_color);
                free(vert_sorted);
                return NULL;
        }
        short i = 0;
        for(short j = 0; j < number_of_vertices; j++){
                if(vert_color[j] != BLACK){
                        struct node *head  = NULL;
                        vert_color[j] = GREY;
                        short *number = (short*)malloc(sizeof(short));
                        *number = j;
                        while(1){
                                struct vertex *current = vertex_list[*number];
                                while(current){
                                        if(vert_color[current->number] != BLACK)
                                                break;
                                        else
                                                current = current->next;
                                }
                                if(!current){
                                        vert_color[*number] = BLACK;
                                        vert_sorted[i++] = *number;
                                        free(number);
                                        number = pop_stack(&head);
                                        if(!number) break;
                                }
                                else
                                if(vert_color[current->number] == GREY){
                                        free(vert_sorted);
                                        free(vert_color);
                                        free_stack(&head);
                                        return NULL;
                                }
                                else{
                                        push_stack(&head, number);
                                        vert_color[current->number] = GREY;
                                        number = (short*)malloc(sizeof(short));
                                        *number = current->number;
                                }
                        }
                }
        }

        free(vert_color);
        return vert_sorted;
}
