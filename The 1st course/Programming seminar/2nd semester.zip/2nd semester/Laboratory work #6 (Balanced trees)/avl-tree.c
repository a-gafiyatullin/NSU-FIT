#include "avl-tree.h"

int max(int left, int right)
{
        return (left > right) ? left : right;
}

struct node *create_node(struct node *parent_node, int value)
{
        struct node *new_node = (struct node*)malloc(sizeof(struct node));
        new_node->parent = parent_node;
        new_node->key = value;
        new_node->height = 1;
        new_node->right_child = new_node->left_child = NULL;

        return new_node;
}

void insert_node(struct node **top_node, int value)
{
        /* find a place in the tree to insert a node */
        if((*top_node) == NULL)
                (*top_node) = create_node(NULL, value);
        else{
                struct node *current_node = (*top_node);
                struct node *parent_node = NULL;
                while(current_node){
                        parent_node = current_node;
                        if(current_node->key >= value)
                                current_node = current_node->left_child;
                        else
                                current_node = current_node->right_child;
                }
                if(parent_node->key >= value)
                        parent_node->left_child = create_node(parent_node, value);
                else
                        parent_node->right_child = create_node(parent_node, value);
                /* balance the tree after the insertion of the new node */
                parent_node = search_unbalanced_tree(parent_node);
                if(parent_node == *top_node)
                        *top_node = balance_tree(parent_node);
                else
                        balance_tree(parent_node);
        }
}

struct node *search_unbalanced_tree(struct node *current_node)
{
        /* find the first unbalanced subtree */
        while(current_node){
                calculate_tree_height(current_node);
                int current_node_balance = get_node_balance(current_node);
                if(current_node_balance > 1 || current_node_balance < -1)
                        return current_node;
                else
                        current_node = current_node->parent;
        }

        return NULL;
}

int get_node_height(struct node *current_node)
{
        return (current_node) ? current_node->height : 0;
}

int calculate_tree_height(struct node *current_node)
{
        if(!current_node)
                return 0;
        unsigned char right_hight = get_node_height(current_node->right_child);
        unsigned char left_hight = get_node_height(current_node->left_child);
        current_node->height = max(left_hight, right_hight) + 1;

        return current_node->height;
}

int get_node_balance(struct node *current_node)
{
        return (current_node) ? get_node_height(current_node->left_child) -
                get_node_height(current_node->right_child) : 0;
}

struct node *right_rotation(struct node *current_node)
{
        struct node *parent_node = current_node->parent;
        struct node *left_child = current_node->left_child;
        if(parent_node){
                if(parent_node->left_child == current_node)
                        parent_node->left_child = left_child;
                else
                        parent_node->right_child = left_child;
        }
        left_child->parent = parent_node;
        current_node->parent = left_child;
        current_node->left_child = left_child->right_child;
        if(left_child->right_child)
                current_node->left_child->parent = current_node;
        left_child->right_child = current_node;
        calculate_tree_height(left_child->right_child);
        calculate_tree_height(left_child);

        return left_child;
}

struct node *left_rotation(struct node *current_node)
{
        struct node *parent_node = current_node->parent;
        struct node *right_child = current_node->right_child;
        if(parent_node){
                if(parent_node->left_child == current_node)
                        parent_node->left_child = right_child;
                else
                        parent_node->right_child = right_child;
        }
        right_child->parent = parent_node;
        current_node->parent = right_child;
        current_node->right_child = right_child->left_child;
        if(right_child->left_child)
                current_node->right_child->parent = current_node;
        right_child->left_child = current_node;
        calculate_tree_height(right_child->left_child);
        calculate_tree_height(right_child);

        return right_child;
}

struct node *balance_tree(struct node *current_node)
{
        if(!current_node)
                return NULL;
        int current_node_balance = get_node_balance(current_node);
        int left_child_balance = get_node_balance(current_node->left_child);
        int right_child_balance = get_node_balance(current_node->right_child);
        if(current_node_balance > 0){
                if(left_child_balance > 0)
                        return right_rotation(current_node);
                else{
                        left_rotation(current_node->left_child);
                        return right_rotation(current_node);
                }
        }
        else{
                if(right_child_balance < 0)
                        return left_rotation(current_node);
                else{
                        right_rotation(current_node->right_child);
                        return left_rotation(current_node);
                }
        }
}

void free_tree(struct node *top_node)
{
        if(!top_node)
                return;
        free_tree(top_node->left_child);
        free_tree(top_node->right_child);
        free(top_node);
}
