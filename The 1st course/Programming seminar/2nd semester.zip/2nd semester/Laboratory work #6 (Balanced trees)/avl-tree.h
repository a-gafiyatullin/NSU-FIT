#ifndef AVL_TREE
#define AVL_TREE

#include "stdlib.h"

/* A structural element of a AVL-tree */
struct node
{
        int key;
        unsigned char height; /* A height of the subtree with root in the current node */
        struct node *parent;
        struct node *right_child;
        struct node *left_child;
};

/* create the node and connect it with its parent */
struct node *create_node(struct node *parent, int value);

/* insert the node in the AVL-tree with the said root and value */
void insert_node(struct node **top_node, int value);

/* find an unbalanced tree with the said root */
struct node *search_unbalanced_tree(struct node *current_node);

/* get a height of the subtree with the said root */
int get_node_height(struct node *current_node);

/*
 get a balance of the subtree with the said root
 if heights of the root's children are right
*/
int get_node_balance(struct node *curent_node);

/*
 calculate a height of the subtree with the said root,
 if heights of the root's children are right
*/
int calculate_tree_height(struct node *current_node);

/*
 a small right rotation
 if the left subtree is higher than the right subtree by two node
*/
struct node *right_rotation(struct node *current_node);

/*
 a small left rotation
 if the right subtree is higher than the left subtree by two node
*/
struct node *left_rotation(struct node *current_node);

/* balance the tree using small right and small left rotation */
struct node *balance_tree(struct node *current_node);

/* free the memory allocated for a tree */
void free_tree(struct node *top_node);

#endif /* AVL_TREE */
