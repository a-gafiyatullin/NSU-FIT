#include "stdio.h"
#include "avl-tree.h"

int main()
{
        struct node *head = NULL;
        int N = 0;

        scanf("%d", &N);
        for(size_t i = 0; i < N; i++){
                int value;
                scanf("%d", &value);
                insert_node(&head, value);
        }
        printf("%d\n", calculate_tree_height(head));

        free_tree(head);
        return 0;
}
