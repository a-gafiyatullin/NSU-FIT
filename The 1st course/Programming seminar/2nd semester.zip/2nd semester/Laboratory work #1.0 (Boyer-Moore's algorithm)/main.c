#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <assert.h>

#define STRING_SIZE 18
#define BLOCK_SIZE 4096

typedef unsigned char uchar;

uchar *create_shift_table(uchar *string, uchar length)
{
	uchar *table = (uchar*)malloc(sizeof(uchar) * 256);
        assert(table);

	memset(table, length, sizeof(uchar) * 256);

	for(size_t i = 0; i < length - 1; i++)
                table[string[i]] = length - (i + 1);

	return table;
}

/* compare pattern and string from the end */
long long int compare(uchar *pattern, uchar *string, long long int length,
         long long int start_position, uchar *stop_symbol)
{
        assert(pattern && string);

        for(long long int i = length - 1; i >= 0; i--)
                if(pattern[i] != string[(BLOCK_SIZE + start_position
                         - (length - i - 1)) % BLOCK_SIZE]){
                        *stop_symbol = string[(BLOCK_SIZE + start_position
                                 - (length - i - 1)) % BLOCK_SIZE];

                        return length - i;
                }

        return length;
}

void print_positions(long long int start, long long int end, FILE *out)
{
        for(long long int i = end; i >= start; i--)
                fprintf(out, "%lld ", i);
}

/* find all entrance of the pattern in the input stream */
void search_pattern(FILE *in, FILE *out, uchar *pattern, size_t length)
{
        assert(in && out);
        uchar *shift_table = create_shift_table(pattern, length);
        uchar *buffer = (uchar*)malloc(sizeof(uchar) * BLOCK_SIZE);
        assert(buffer);
        long long int i = length - 1, remainder = 0, compared = 0, read = 0, shift = 0;
        uchar stop_symbol = 0, READ_FLAG = 1, REMAINDER_READ_FLAG = 0;
        while(1){
                /* read the beginning of the buffer */
                if(READ_FLAG){
                        read = fread(buffer, sizeof(uchar), BLOCK_SIZE - remainder, in);
                        if(read == 0) break;
                        REMAINDER_READ_FLAG = remainder;
                        READ_FLAG = 0;
                }
                /* calculate a shift of the iterator */
                if((compared = compare(pattern, buffer, length, i % BLOCK_SIZE,
                         &stop_symbol)) == length)
                        shift = length;
                else
                if(stop_symbol){
                        shift = shift_table[stop_symbol] - ((compared != 1) ? 1 : 0);
                        if((i + 1) % BLOCK_SIZE == 0){
                                READ_FLAG = 1;
                                remainder = length - shift;
                        }
                        else
                        if(((i + 1) % BLOCK_SIZE) + shift > BLOCK_SIZE){
                                READ_FLAG = 1;
                                remainder = length - (((i + 1) % BLOCK_SIZE)
                                        + shift - BLOCK_SIZE);
                        }
                }
                else
                        break;
                print_positions(i - compared + 2, i + 1, out);
                if(i % BLOCK_SIZE + shift > read + remainder && !READ_FLAG)
                        break;
                i += shift;
                /* read the ending of the buffer */
                if(REMAINDER_READ_FLAG && (i % BLOCK_SIZE) - length + 1 >= 0){
                        fread(buffer + (BLOCK_SIZE - remainder), sizeof(uchar),
                         remainder, in);
                        REMAINDER_READ_FLAG = 0;
                }
        }
        free(shift_table);
        free(buffer);
}

int main()
{
        FILE *in = fopen("in.txt", "r");
        FILE *out = fopen("out.txt", "w");
	uchar pattern[STRING_SIZE];

	fgets(pattern, STRING_SIZE, in);
	size_t length = strlen(pattern);
	pattern[--length] = '\0';

	search_pattern(in, out, pattern, length);

        fclose(in);
        fclose(out);
	return 0;
}
