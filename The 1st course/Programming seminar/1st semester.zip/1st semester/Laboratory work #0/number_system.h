#ifndef NUMBER_SYSTEM_H
#define NUMBER_SYSTEM_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int sys_check(char *str, short base);

long double to_decemical(char* number, short base);

void integer_to_new_sys(long long int number, short base);

void fractional_to_new_sys(long double number, short base);

#endif
