#include "number_system.h"

char alpha_to_digits(char ch){
	if (isdigit(ch))
		return ch - '0';
	if (isalpha(ch))
		return tolower(ch) - 'W';
	return 0;
}

void digits_to_alpha(char ch){
	if (isdigit(ch + '0'))
		printf("%d", ch);
	else
	if (isalpha(ch+'W'))
		printf("%c", ch + 'W');
}

int sys_check(char *str, short base){
	if (*str == '.')
		return 0;
	while (*str){
		if (alpha_to_digits(*str) >= base)
			return 0;
		else
		if (*str == '.' && !isalnum(*(str+1)))
			return 0;
		str++;
	}
	return 1;
}

long double to_decemical(char* number, short base){
	long double rezult = 0;
	int j = 0, i=0;
	while (number[i++] != '.' && number[i])
		;
	while (number[i++])
		j--;
	for (i = strlen(number) - 1; i >= 0; i--, j++)
		if (number[i] != '.')
			rezult = rezult + (alpha_to_digits(number[i]) * pow(base, j));
		else
			j--;
	return rezult;
}

void integer_to_new_sys(long long number, short base){
	if (number >= base)
		integer_to_new_sys(number / base, base);
	digits_to_alpha(number%base);
}

void fractional_to_new_sys(long double number, short base){\
	int i;
	for (i = 0; i < 12 && number != 0.0; i++){
		number = number * base;
		digits_to_alpha((int)number);
		number = number - (int)number;
	}
}
