#include "number_system.h"

int main(){

	char number[14];
	int b1, b2;
	long double decemical;

	scanf("%d%d\n%s", &b1, &b2, number);
	if (b1 <= 1 || b2 <= 1 || b1 > 16 || b2 > 16 || !sys_check(number, b1)){
		printf("bad input");
		return 0;
	}
	decemical = to_decemical(number, b1);
	integer_to_new_sys(decemical, b2);
	if(decemical - (long long)decemical != 0.0){
		putchar('.');
		fractional_to_new_sys(decemical - (long long)decemical, b2);
	}
	return 0;
}
