#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <ctype.h>

#define STRING_SIZE 18
#define BLOCK_SIZE 4096
#define BASE 3

typedef long long int ll;

/* calculate hash of a symbol */
ll hash_function(char symbol, ll power)
{
	return ((unsigned char)symbol % BASE) * power;
}

/* calculate hash of a string */
ll string_hash(char *string, size_t length, ll *power)
{
	if(string[0] == EOF || string[0] == '\0')
		return -1;
	
	ll hash = 0;
	
	for(size_t i = 0; i < length; i++){
		hash += hash_function(string[i], *power);
		(*power) *= BASE;
	}
	
	(*power) /= BASE;
	return hash;
}

/* print all positions from (pos + 1 - length) up to (pos + 1 - length + number) */
void print_positions(FILE *file, size_t pos, size_t number, size_t length)
{
	size_t starting_index = pos + 1 - length;
	
	for(size_t i = starting_index; i < starting_index + number; i++)
		fprintf(file, "%ld ", i);
}

/* test equality of strings with and without a shift */ 
size_t test_equality(char *left, char *right, size_t length)
{
	ssize_t i = 0, j = 0;
	
	/* compare without the shift */
	while(j < length - 1 && left[j] == right[j])
		j++;
	
	/* compare with the shift */
	if(left[length - 1] == right[0]){
		while(left[i] == right[i+1] && i < length - 1){
			i++;
		}
	}
	
	return ((i + 1) > (j + 1) ? (i + 1) : (j + 1));
}

/* 
 * search a pattern in the input stream 
 * and save the pattern hash and entrance positions
 * in the output stream
 */
void search_pattern(FILE *in, FILE *out, char *pattern, size_t length)
{
	char cache[BLOCK_SIZE] = {'\0'};
	cache[0] = 1;
	char* string = (char*)malloc(sizeof(char) * (length + 1));
	if(string == NULL)
		exit(-1);
	
	ll power = 1;
	ll work_protocol = string_hash(pattern, length, &power);
	fprintf(out, "%lld ", work_protocol);
	
	power = 1;
	size_t i = 0;
	while(i < length && (string[i++] = getc(in)) != EOF)
		;
	string[length] = '\0';
	ll current_hash = string_hash(string, length, &power);
	
	size_t compare = 0;
	while(cache[(i - length) % BLOCK_SIZE] != '\0'){
		if((i - length) % BLOCK_SIZE == 0)
			if(fread(cache, sizeof(char), BLOCK_SIZE, in) == 0)
				break;
		if(current_hash == work_protocol){
			compare = test_equality(pattern, string, length);
			print_positions(out, i, compare, length);
		}
		current_hash = (current_hash - hash_function(string[i % length], 1)) / BASE;
		string[i % length] = cache[(i - length) % BLOCK_SIZE];
		current_hash += hash_function(string[i % length], power);
		i++;
	}
	if(current_hash == work_protocol){
		compare = test_equality(pattern, string, length);
		print_positions(out, i, compare, length);
	}
	
	free(string);
}

int main()
{
	FILE *in = fopen("in.txt", "r"), *out = fopen("out.txt", "w");
	if(in == NULL || out == NULL)
		return (in != out) ? fclose((in == NULL) - 1 ? in : out) : -1;
		
	char pattern[STRING_SIZE];
	
	fgets(pattern, STRING_SIZE, in);
	size_t length = strlen(pattern);
	pattern[--length] = '\0';
	
	search_pattern(in, out, pattern, length);
	
	fclose(in);
	fclose(out);
	return 0;
}
