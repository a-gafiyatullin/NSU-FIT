#ifndef QUICK_SORT
#define QUICK_SORT

#include "quick_sort_main_func.h"

void quick_sort(int *array, size_t size);
/* interface for rec_sort */

#endif /* QUICK_SORT */



