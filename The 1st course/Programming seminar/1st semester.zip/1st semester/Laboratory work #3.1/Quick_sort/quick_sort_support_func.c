#include "quick_sort_support_func.h"

extern inline void swap(int *left, int *right);

size_t partition(int *array, size_t left, size_t right)
{
	size_t right_iter = right;

	while(1){
		while(array[++left] < array[right])
			;

		while(array[--right_iter] > array[right])
			;

		if(left >= right_iter)
			break;
		else
			swap(array + left, array + right_iter);
	}

	/* return right element (it's our median) to its real position */
	swap(array + left, array + right);
	return left;
}

size_t median_of3(int *array, size_t left, size_t right)
{
	int center = (left + right) / 2;

	/* sort three elements */
	if(array[left] > array[center])
		swap(array + left, array + center);
	if(array[left] > array[right])
		swap(array + right, array + left);
	if(array[center] > array[right])
		swap(array + right, array + center);

	/*
	 * center element is our median, so put its to right border of subarray
	 */
	swap(array + center, array + right);
	return right;
}

