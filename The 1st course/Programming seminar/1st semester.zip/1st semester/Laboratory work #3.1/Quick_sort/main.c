/*
 * Albert Gafiyatullin <a.gafiyatullin@g.nsu.ru>
 * Novosibirsk State University, Faculty of Information Technologies
 */

#include <stdio.h>
#include <stdlib.h>
#include "quick_sort.h"

int main(void)
{
	size_t size;
	scanf("%u", &size);
	int *array = (int *)malloc(size * sizeof(int));
	if(array == NULL)
		exit(-1);
		fprintf(stderr, "%u", size);
	for(size_t i = 0; i < size; i++)
		scanf("%d", array + i);

	quick_sort(array, size);

	for(size_t i = 0; i < size; i++)
		printf("%d ", array[i]);

	free(array);
	array = NULL;
	return 0;
}
