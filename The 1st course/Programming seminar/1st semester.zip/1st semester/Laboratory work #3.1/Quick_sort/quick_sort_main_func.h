#ifndef QUICK_SORT_MAIN_FUNC
#define QUICK_SORT_MAIN_FUNC

#include "quick_sort_support_func.h"

/* Main functions */

void rec_sort(int *array, size_t left, size_t right);
/* recursive function for quick sort */

void insertion_sort(int *array, size_t left, size_t right);
/*
 * insertion sort for arrays with size lesser than 10;
 * according to D. Knuth (The Art of Computer Programming)
 * it does quick sort algorithm faster
 */

#endif /* QUICK_SORT_MAIN_FUNC */


