#include "quick_sort_main_func.h"

void rec_sort(int *array, size_t left, size_t right)
{
	size_t size = right - left + 1;
	if(size < 10)
		insertion_sort(array, left, right);
	else {
		median_of3(array, left, right);
		size_t part = partition(array, left, right);
		/*
		 * element with "part" index is already have sorted
		 */
		rec_sort(array, left, part - 1);
		rec_sort(array, part + 1, right);
	}
}

void insertion_sort(int *array, size_t left, size_t right)
{
	for(size_t out = left + 1; out <= right; out++){
		int temp = array[out];

		size_t in = out;
		while(in > left && array[in - 1] >= temp){
			array[in] = array[in - 1];
			in--;
		}
		array[in] = temp;
	}
}

