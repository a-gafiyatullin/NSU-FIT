#ifndef QUICK_SORT_SUPPORT_FUNC
#define QUICK_SORT_SUPPORT_FUNC

#include <stddef.h>
/* Support functions */

inline void swap(int *left, int *right)
{
	int temp = *left;
	*left = *right;
	*right = temp;
}
/* swap two elements using pointers */

size_t partition(int *array, size_t left, size_t right);
/* array partition function */

size_t median_of3(int *array, size_t left, size_t right);
/* search median of 3 elements of array and return median */

#endif /* QUICK_SORT_SUPPORT_FUNC */

