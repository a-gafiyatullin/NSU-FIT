#include "quick_sort.h"

void quick_sort(int *array, size_t size)
{
	rec_sort(array, 0, size - 1);
}
