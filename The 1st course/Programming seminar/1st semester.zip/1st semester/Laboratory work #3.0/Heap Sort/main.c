#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

void trickle_down(int *array, size_t index, size_t max_size)
{
	int value = array[index];
	int larger_child;
	while(index <= (max_size / 2)){
		size_t left_child = index * 2;
		size_t right_child = left_child + 1;
		/*
		 * if the right child of the current index exist,
		 * choose the largest from children
		 */
		if(right_child <= max_size && array[left_child] < array[right_child])
			larger_child = right_child;
		else
			larger_child = left_child;
		/* if index for insert is found, then break loop */
		if(array[larger_child] <= value)
			break;
		array[index] = array[larger_child];
		index = larger_child;
	}
	array[index] = value;
}

int main()
{
	size_t size;
	scanf("%lu", &size);
	int *array = (int*)malloc(sizeof(int) * ++size);
	assert(array != NULL);
	
	for(size_t i = 1; i < size; i++)
		scanf("%d", array + i);
	
	/* rebuild a heap */
	for(size_t i = size / 2; i > 0; i--)
		trickle_down(array, i, size - 1);
	size_t current_size = size - 1;
	
	/* remove the largest element and restore the heap */
	for(size_t i = size - 1; i > 0; i--){
		int value = array[1];
		array[1] = array[i];
		array[i] = value;
		trickle_down(array, 1, --current_size);
	}
	
	for(size_t i = 1; i < size; i++)
		printf("%d ", array[i]);
	
	free(array);
	return 0;
}
