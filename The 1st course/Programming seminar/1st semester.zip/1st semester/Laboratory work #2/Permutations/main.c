#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SIZE 11

void swap(char *left, char *right)
{
	char temp = *left;
	*left = *right;
	*right = temp;
}

int compare(const void *left, const void *right)
{
	return *((char*)left) - *((char*)right);
}

char *next_permutation(char *current_permutation, size_t length)
{
	int i,j;
	
	for(i = length - 1; i >= 0; i--)
		if(current_permutation[i] > current_permutation[i - 1])
			break;
	for(j = length - 1; j >= 0; j--)
		if(current_permutation[j] > current_permutation[i - 1])
			break;
		
	swap(current_permutation + j, current_permutation + i - 1);
	if(length - i > 1)
		qsort(current_permutation + i, length - i, sizeof(current_permutation[0]), compare);
	
	return current_permutation;
}

int is_permutation(char *current_permutation, size_t length)
{
	short existance[11] = {0};
	for(int i = 0; i < length; i++){
		if(!isdigit(current_permutation[i]))
			return 0;
		if(existance[current_permutation[i] - '0'])
			return 0;
		else
			existance[current_permutation[i] - '0'] = 1;
	}
	
	return 1;
}

int is_last_permutation(char *current_permutation, size_t length)
{
	for(int i = 0; i < length - 1; i++)
		if(current_permutation[i] <= current_permutation[i+1])
			return 0;
		
	return 1;
}

int main()
{
	char permutation[SIZE];
	int N;
	scanf("%s%d", permutation, &N);
	
	if(is_last_permutation(permutation, strlen(permutation)))
		return 0;
	if(is_permutation(permutation, strlen(permutation)))
		for(int i = 0; i < N && !is_last_permutation(permutation,strlen(permutation)); i++)
			printf("%s\n", next_permutation(permutation, strlen(permutation)));
	else
		printf("bad input");
	
	return 0;
}
