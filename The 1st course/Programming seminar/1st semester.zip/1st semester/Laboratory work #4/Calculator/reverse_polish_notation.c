#include "reverse_polish_notation.h"

int operation_priority(char ch)
{
	switch(ch){
	case '(':
		return 0;
	case '+':
	case '-':
		return 1;
	case '*':
	case '/':
		return 2;
	}
}

struct node *parse_expr(char *str, size_t length, struct node *expression)
{
	struct node *operations = NULL; /* the stack for the operations */
	for(size_t i = 0; i < length; i++){
		if(isdigit(str[i])){
			char num[11];
			int j = 0;
			while(isdigit(str[i]))
				num[j++] = str[i++];
			num[j] = '\0';
			push(&expression, atoi(num), 0);
			i--;
		}/* if symbol is digit, push it to the expression stack */
		else{
			if(str[i] == '(')
				push(&operations,str[i], 1); /* if symbol is '(', push it to the operations stack */
			else
			if(str[i] == ')'){
				int symbol;
				/* 
				 * if symbol is ')', pop all operations from the operation stack up to the '(' symbol
				 * and push them to the expression stack 
				 */
				while((symbol = pop(&operations)) != '(') 
					push(&expression, symbol, 1);
			}
			else
			if(operations == NULL)
				push(&operations, str[i], 1); /* if operations stack is empty, push the first operation */
			else{
				/* 
				 * if priority of the previous operation is lesser than priority of the current one, 
				 * push the present operation to the operation stack
				 */
				if(operation_priority(operations->data) < operation_priority(str[i]))
					push(&operations, str[i], 1);
				else{
					/*
					 * else pop all operations from the operation stack up to the '(' symbol, NULL pointer or
					 * less priority operation than current one and push them to the expression stack 
					 */
					while(operations != NULL && operation_priority(operations->data) >= operation_priority(str[i]))
						push(&expression, pop(&operations), 1);
					push(&operations, str[i], 1);
				}
			}
				
		}
		
	}
	/* 
	 * if operations stack is not empty, pop all elements from it and push them to the expression stack 
	 */
	while(operations != NULL)
		push(&expression, pop(&operations), 1);
	
	return expression->prev;
}

