#ifndef STACK_H
#define STACK_H

#include <stddef.h> 
#include <stdlib.h>
#include <stdio.h>

/* 
 * structure element of our stack 
 * "type" field is 0 if "data"" is number, else 1
 */
struct node
{
	int data; 
	int type; 
	struct node *next;
	struct node *prev;
};

/* push element to stack */
void push(struct node**, int, int);

/* pop element from stack and return its data */
int pop(struct node**);

/*free stack memory */
void free_stack(struct node*);

#endif /* STACK_H */



