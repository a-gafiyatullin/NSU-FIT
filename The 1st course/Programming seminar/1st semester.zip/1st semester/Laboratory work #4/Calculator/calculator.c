#include "calculator.h"

int syntax_test(char *str, size_t length)
{
	/* a expression must start and end with a digit or a bracket */
	if((!isdigit(str[0]) && str[0] != '(' ) || (!isdigit(str[length-1]) && str[length-1] != ')'))
		return 0;
	
	int operations = 0;
	int digits = 0;
	int open_brackets = 0;
	int close_brackets = 0;
	
	/* if a symbol is not a digit, a operation or a bracket then return a syntax error */
	for(size_t i = 0; i < length; i++)
		if(isdigit(str[i])){
			while(isdigit(str[++i]))
				;
			digits++;
			i--;
		}
		else
		switch(operation_priority(str[i])){
			case 0: open_brackets++; 
				break;
			case 1: 
			case 2:	operations++; 
				break;
			default: if(str[i] == ')') close_brackets++;
					else return 0; 
		}
		
	if(open_brackets != close_brackets || length == 0 || (digits - operations) != 1)
		return 0;
	/* if number is between brackets, it is not a syntax error */
	if(digits == 1 && operations == 0 && open_brackets != 0 && (str[0] != '(' || str[length - 1] != ')'))
		return 0;
	
	return 1;	
}

int do_operation(char operation, int left_operand, int right_operand)
{
	if(operation == '/' && right_operand == 0){
		printf("division by zero");
		exit(0);
	}
	
	switch(operation){
		case '+': return left_operand + right_operand;
		case '-': return left_operand - right_operand;
		case '*': return left_operand * right_operand;
		case '/': return left_operand / right_operand;
	}
}

int calculate(struct node *expression)
{
	struct node *rezult_stack = NULL;
	struct node *temp = expression;
	do{
		/* find the first operation in the expression and do its with two previous operands */
		if(expression->type == 0){
			push(&rezult_stack, expression->data, 0);
			expression = expression->prev;
		}
		else{
			int left_operand = pop(&rezult_stack);
			int right_operand = pop(&rezult_stack);
			push(&rezult_stack, do_operation(expression->data, right_operand, left_operand), 0);
			expression = expression->prev;
		}
	}while(expression != temp);
	
	free_stack(expression);
	return pop(&rezult_stack);
}

