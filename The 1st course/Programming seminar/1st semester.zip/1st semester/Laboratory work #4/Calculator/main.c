#include "calculator.h"
#include <string.h>

/* MAX SIZE of a input string */
#define SIZE 1002

int main(void)
{
	struct node *polish_notation_head = NULL;
	char str[SIZE];
	fgets(str, SIZE, stdin);
	
	if(syntax_test(str, strlen(str) - 1)){
		polish_notation_head = parse_expr(str, strlen(str) - 1, polish_notation_head);
		printf("%d", calculate(polish_notation_head));
	}
	else
		printf("syntax error");
	
	return 0;
}
