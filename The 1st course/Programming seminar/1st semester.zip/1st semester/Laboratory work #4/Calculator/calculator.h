#ifndef CALCULATOR_H
#define CALCULATOR_H

#include "reverse_polish_notation.h"

/* test for mistakes in the input string */
int syntax_test(char*, size_t);

/* calculate the arithmertical expression in the reverse polish notation */
int calculate(struct node*);

/* do the operation with two operands */
int do_operation(char, int, int);

#endif /* CALCULATOR_H */
