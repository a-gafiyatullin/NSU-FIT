#ifndef REVERSE_POLISH_NOTATION_H
#define REVERSE_POLISH_NOTATION_H

#include "stack.h"
#include <ctype.h>

/* transformate the normal notation to the polish notation */
struct node *parse_expr(char*, size_t, struct node*);

/* return a priority of the arithmetic operation */
int operation_priority(char);

#endif /* REVERSE_POLISH_NOTATION_H */
