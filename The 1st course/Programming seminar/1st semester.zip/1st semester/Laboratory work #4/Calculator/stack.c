#include "stack.h"

void push(struct node **element, int data, int type)
{
	struct node *new_node = NULL;
	new_node = (struct node*)malloc(sizeof(struct node)); 
	if(new_node == NULL)
		exit(-1);

	new_node->data = data;
	new_node->type = type;
	
	new_node->next = (*element);
	if(*element == NULL)
		new_node->prev = new_node;
	else
		new_node->prev = (*element)->prev;
	if(*element != NULL)
		(*element)->prev = new_node;
	*element = new_node;
}

int pop(struct node **element)
{
	if(*element == NULL)
		return 0;
	
	int data = (*element)->data;
	
	struct node *next_node = NULL;
	struct node *prev_node = NULL;
	
	next_node = (*element)->next;
	prev_node = (*element)->prev;
	free(*element);
	
	if(prev_node != *element){
		if(prev_node != NULL)
			prev_node->next = next_node;
		if(next_node != NULL)
			next_node->prev = prev_node;
		*element = next_node;
	}
	else
		*element = NULL;
	
	return data;
}

void free_stack(struct node *element)
{
	if(element == NULL)
		return;
	
	struct node *next = element->next;
	struct node *prev = element->prev;
	
	while(next != NULL){
		next = next->next;
		free(next->prev);
	}
	
	while(prev != element){
		prev = prev->prev;
		free(prev->next);
	}
	
	free(element);
}



